var express = require("express"),
	app = express(),
	path = require ("path")
	bodyParser = require('body-parser'),
	session = require('express-session'),
	port = 8000;

app.use(express.static (path.join(__dirname + "/static")) );
app.use(bodyParser.urlencoded({extended: true}));
app.use(session({
    secret: 'secretpassword',
    proxy: true,
    resave: false,
    saveUninitialized: true
}));
app.set('views', path.join(__dirname + '/views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    return res.render('index');
});

app.post('/result', function (req, res){
	var dojo_user_form = {
        name: req.body.name,
        location: req.body.location,
        language: req.body.language,
        comment: req.body.comment

    };
    console.log(dojo_user_form);
    res.render("success", {dojo_user: dojo_user_form});
});

// app.post('/submit', function (req, res){

//     return res.redirect('/results');
// });

app.post("/gohome", function(req, res) {

    res.redirect("/");

});

app.listen(port, function() {
    console.log(`listening on port 8000`);
});