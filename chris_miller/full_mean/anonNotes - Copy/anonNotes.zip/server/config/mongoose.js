var mongoose = require("mongoose"),
	db_name  = "";

mongoose.connect(`mongodb://localhost/${db_name}`);